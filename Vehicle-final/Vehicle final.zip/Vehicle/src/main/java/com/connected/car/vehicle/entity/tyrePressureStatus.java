package com.connected.car.vehicle.entity;

public enum tyrePressureStatus {
    NORMAL, UNDERINFLATED, OVERINFLATED, UNKNOWN;
}
