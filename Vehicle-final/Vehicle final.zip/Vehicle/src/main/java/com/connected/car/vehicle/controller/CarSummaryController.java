package com.connected.car.vehicle.controller;

import com.connected.car.vehicle.Constants.ResponseMessage;
import com.connected.car.vehicle.entity.CarSummary;
import com.connected.car.vehicle.entity.TripDetails;
import com.connected.car.vehicle.repository.CarSummaryRepository;
import com.connected.car.vehicle.repository.TripDetailsRepository;
import com.connected.car.vehicle.response.ApiResponse;

import com.connected.car.vehicle.service.CarSummaryService;
import com.connected.car.vehicle.service.impl.CarSummaryImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/v1/api/carSummary")
public class CarSummaryController {

    @Autowired
    private CarSummaryImpl carSummaryImpl;

    @Autowired
    private CarSummaryRepository carSummaryRepository;

    @Autowired
            private TripDetailsRepository tripDetailsRepository;

    ApiResponse apiResponse;

    @GetMapping("/getCarSummary")
    public ResponseEntity<ApiResponse> getCarSummary(@RequestParam long carId, @RequestParam long tripDetailsId)
    {
        carSummaryImpl.getCarSummary(carId,tripDetailsId);
        CarSummary carSummary=carSummaryRepository.findCarSummaryByTripDetailsId(tripDetailsId);
        ApiResponse apiResponse=new ApiResponse(ResponseMessage.CALCULATION_SUCCESS_MESSAGE,true, carSummary);
        return new ResponseEntity<>(apiResponse,HttpStatus.OK);
    }

   @GetMapping("/listOfTripsForCar")
   public ResponseEntity<ApiResponse> getListOfTripDetailsForCarId(@RequestParam long carId)
   {
       List<TripDetails> tripDetailsList=carSummaryImpl.listOfTripForCarId(carId);
       //System.out.println(tripDetailsList);
       apiResponse=new ApiResponse(ResponseMessage.TRIP_DETAILS_FETCH_MESSAGE, true, tripDetailsList);
       return new ResponseEntity<>(apiResponse,HttpStatus.OK);
   }


    @GetMapping("/calculateMileage")
    public ResponseEntity<ApiResponse> calculateMileage(@RequestParam long carId, @RequestParam long tripDetailsId)
    {
        //exception handling pending
        double mileage=carSummaryImpl.calculateMileage(carId,tripDetailsId);
        apiResponse=new ApiResponse(ResponseMessage.CALCULATION_SUCCESS_MESSAGE,true,mileage);
        return new ResponseEntity<>(apiResponse, HttpStatus.OK);
    }
    @GetMapping("/calculate-fuel-consumption")
    public ResponseEntity<ApiResponse> calculateFuelConsumption(@RequestParam long carId, @RequestParam long tripDetailsId) {
        double fuelConsumption = carSummaryImpl.calculateFuelConsumption(carId,tripDetailsId);
        apiResponse=new ApiResponse(ResponseMessage.FUEL_CONSUMPTION_SUCCESS,true,fuelConsumption);
        return new ResponseEntity<>(apiResponse, HttpStatus.OK);
    }

    @GetMapping("/calculateCurrentAvgMileage")
    public ResponseEntity<ApiResponse> calculatePresentAvgMileage(@RequestParam long carId){
       List<TripDetails> tripDetailsList=carSummaryImpl.listOfTripForCarId(carId);
       List<Long> tripDetailsIdList=new ArrayList<>();
       for(int i=0;i<tripDetailsList.size();i++) {
           tripDetailsIdList.add(tripDetailsList.get(i).getTripDetailsId());
       }

      double avgMileage= carSummaryImpl.calculatePresentAvgMileage(carId, tripDetailsIdList);
       ApiResponse apiResponse=new ApiResponse(ResponseMessage.CALCULATION_SUCCESS_MESSAGE,true,avgMileage);
       return new ResponseEntity<>(apiResponse,HttpStatus.OK);

    }


    @GetMapping("/calculate-totalDistance")
    public ResponseEntity<ApiResponse> calculateTotalDistance(@RequestParam long carId, @RequestParam long tripDetailsId) {
        double TotalDistance = carSummaryImpl.calculateFuelConsumption(carId,tripDetailsId);
        apiResponse=new ApiResponse(ResponseMessage.Distance_Calculation_Success,true,TotalDistance);
        return new ResponseEntity<>(apiResponse, HttpStatus.OK);
    }

    @GetMapping("/calculate-Duration")
    public ResponseEntity<ApiResponse> calculateDuration(@RequestParam long carId, @RequestParam long tripDetailsId) {
        double duration = carSummaryImpl.calculateDuration(carId, tripDetailsId);
        apiResponse=new ApiResponse(ResponseMessage.DURATION_CALCULATION_SUCCESS,true,duration);
        return new ResponseEntity<>(apiResponse, HttpStatus.OK);
    }




}
