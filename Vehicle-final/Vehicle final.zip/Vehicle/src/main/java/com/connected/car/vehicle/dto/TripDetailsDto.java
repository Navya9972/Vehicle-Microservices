package com.connected.car.vehicle.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TripDetailsDto {
    private long tripDetailsId;

    private long carId;
    private double maxSpeed;
    private double minSpeed;
    private LocalDateTime travelStartDateTime;
    private LocalDateTime travelEndDateTime;

    private double initialFuelReading;
    private double currentFuelReading;
    private double odometerStartReading;
    private double odometerEndReading;

    private boolean active;
}
