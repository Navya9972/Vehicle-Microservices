package com.connected.car.vehicle.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.connected.car.vehicle.dto.CarDto;
import com.connected.car.vehicle.entity.Car;
import com.connected.car.vehicle.exceptions.ResourceNotFoundException;
import com.connected.car.vehicle.repository.CarRepository;
import com.connected.car.vehicle.service.CarService;

@Service
public class CarServiceImpl implements CarService{

	@Autowired
	private CarRepository carRepository;
	
	@Override
	public CarDto createCar(CarDto carDto) {
		Car car=dtoToEntity(carDto);
		Car savedCar=carRepository.save(car);
		return entityToDto(savedCar);
	}

	@Override
	public CarDto getCarById(Integer carId) {
		Car car=carRepository.findById(carId)
				.orElseThrow(()-> new ResourceNotFoundException("Car", " Id ", carId));
		return entityToDto(car);
	}
	
	@Override
	public List<CarDto> getAllCars() {
		List<Car> cars=carRepository.findAll();
		List<CarDto> carDtos=cars.stream().map(car->entityToDto(car)).collect(Collectors.toList());
		return carDtos;
	}
	
	@Override
	public CarDto updateCar(CarDto carDto, Integer carId) {
		Car car=carRepository.findById(carId)
				.orElseThrow(( )-> new ResourceNotFoundException("User", " Id ", carId));
		car.setModel(carDto.getModel());
		car.setDescription(carDto.getDescription());
		car.setRegistrationNumber(carDto.getRegistrationNumber());
		car.setManufacturer(carDto.getManufacturer());
		car.setManufactureYear(carDto.getManufactureYear());
		Car updatedCar=carRepository.save(car);
		CarDto carDto1=entityToDto(updatedCar);
		return carDto1;
	}
	
	@Override
	public void deleteCar(Integer carId) {
		Car car=carRepository.findById(carId).orElseThrow(()-> new ResourceNotFoundException("Car", " Id ", carId));
		carRepository.delete(car);
	}
	
	private Car dtoToEntity(CarDto carDto) {
		Car car=new Car();
		car.setCarId(carDto.getCarId());
		car.setModel(carDto.getModel());
		car.setDescription(carDto.getDescription());
		car.setRegistrationNumber(carDto.getRegistrationNumber());
		car.setManufacturer(carDto.getManufacturer());
		car.setManufactureYear(carDto.getManufactureYear());
		return car;
	}
	
	private CarDto entityToDto(Car car) {
		CarDto carDto=new CarDto();
		carDto.setCarId(car.getCarId());
		carDto.setModel(car.getModel());
		carDto.setDescription(car.getDescription());
		carDto.setRegistrationNumber(car.getRegistrationNumber());
		carDto.setManufacturer(car.getManufacturer());
		carDto.setManufactureYear(car.getManufactureYear());
		return carDto;
	}

	

	

	


	
}
