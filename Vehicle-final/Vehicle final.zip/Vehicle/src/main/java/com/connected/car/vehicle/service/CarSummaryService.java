package com.connected.car.vehicle.service;

import com.connected.car.vehicle.entity.TripDetails;

import java.util.List;


public interface CarSummaryService {
    public double calculateMileage(long carId, long tripDetailsId);

    public List<TripDetails> listOfTripForCarId(long carId);
    public double calculateFuelConsumption(long carId, long tripDetailsId);

    double calculatePresentAvgMileage(long carId,List<Long> tripDetailsIdList);
    public double calculateTotalDistance(long carId, long tripDetailsId);

    public double calculateDuration(long carId, long tripDetailsId);
    public void getCarSummary(long carId,long tripDetailsId);
}
