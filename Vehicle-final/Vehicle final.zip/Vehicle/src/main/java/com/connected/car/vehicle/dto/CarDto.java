package com.connected.car.vehicle.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Getter
@Setter
public class CarDto {

	private int carId;
	private String model;
	private String description;
	private String registrationNumber;
	private String manufacturer;
	private String manufactureYear;
}
