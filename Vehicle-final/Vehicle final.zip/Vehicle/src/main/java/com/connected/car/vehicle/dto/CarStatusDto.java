package com.connected.car.vehicle.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CarStatusDto {
    private long carStatusId;

    private long tripDetailsId;
    private com.connected.car.vehicle.entity.fuelStatus fuelStatus;
    private com.connected.car.vehicle.entity.tyrePressureStatus tyrePressureStatus;
    private boolean lock_status;
    private com.connected.car.vehicle.entity.batteryStatus batteryStatus;

}
