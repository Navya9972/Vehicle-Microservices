package com.connected.car.vehicle.repository;

import com.connected.car.vehicle.entity.TripDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface TripDetailsRepository extends JpaRepository<TripDetails,Long> {
   // @Query("SELECT t FROM TripDetails t where t.carId=?1")
    public List<TripDetails> findAllTripDetailsByCarId(long carId);
    @Query("SELECT c.initialFuelReading from TripDetails c where c.tripDetailsId=?1")
    public double findInitialFuelReadingByTripDetailsId(@Param("trip_details_id")long tripDetailsId);

    @Query("SELECT c.currentFuelReading from TripDetails c where c.tripDetailsId=?1")
    public double findCurrentFuelReadingByTripDetailsId(@Param("trip_details_id")long tripDetailsId);

 @Query("SELECT c.odometerStartReading from TripDetails c where c.tripDetailsId=?1")
 public double findOdometerStartReadingByTripDetailsId(@Param("trip_details_id")long tripDetailsId);

 @Query("SELECT c.odometerEndReading from TripDetails c where c.tripDetailsId=?1")
 public double findOdometerEndReadingByTripDetailsId(@Param("trip_details_id")long tripDetailsId);

 @Query("SELECT c.travelStartTime from TripDetails c where c.tripDetailsId=?1")
 public double findTravelStartTimeByTripDetailsId(@Param("trip_details_id")long tripDetailsId);

 @Query("SELECT c.travelEndTime from TripDetails c where c.tripDetailsId=?1")
 public double findTravelEndTimeByTripDetailsId(@Param("trip_details_id")long tripDetailsId);


}


