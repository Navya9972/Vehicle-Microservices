package com.connected.car.vehicle.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CarSummaryDto {
    private long carSummaryId;

    private long tripDetailsId;
    private double mileage;
    private double averageMileage;
    private double fuelConsumption;
    private double totalDistance;
    private LocalTime idleTime;
    private LocalTime duration;
}
