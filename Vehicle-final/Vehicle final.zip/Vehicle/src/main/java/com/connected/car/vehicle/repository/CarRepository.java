package com.connected.car.vehicle.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.connected.car.vehicle.entity.Car;

public interface CarRepository extends JpaRepository<Car, Integer>{

    public Car findByCarId(long carId);


}
