package com.connected.car.vehicle.repository;

import com.connected.car.vehicle.entity.CarSummary;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface CarSummaryRepository extends JpaRepository<CarSummary,Long> {

    public CarSummary findCarSummaryByTripDetailsId(long tripDetailsId);

    @Query("SELECT c.fuelConsumption from CarSummary c where c.tripDetailsId=?1")
    public double findFuelConsumptionByTripDetailsId(@Param("trip_details_id") long tripDetailsId);


    @Query("SELECT c.totalDistance from CarSummary c where c.tripDetailsId=?1 ")
    public double findTotalDistanceByTripDetailsId(@Param("trip_details_id") long tripDetailsId);


}
