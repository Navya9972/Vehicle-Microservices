package com.connected.car.vehicle.Constants;

public class ResponseMessage {
    public static final String CALCULATION_SUCCESS_MESSAGE="Car parameter calculated Successfully";
    public static final String TRIP_DETAILS_FETCH_MESSAGE=" Trip Details fetched Successfully";

    public static final String FUEL_CONSUMPTION_SUCCESS = "Car Fuel consumption calculated successfully";

    public static final String Distance_Calculation_Success = "Total Distance travelled by the car is calculated";
    public static final String 	DURATION_CALCULATION_SUCCESS ="Duration of the ar is calculated";

}
