package com.connected.car.vehicle.entity;

public enum fuelStatus {
    LOW, MEDIUM, HIGH;
}
