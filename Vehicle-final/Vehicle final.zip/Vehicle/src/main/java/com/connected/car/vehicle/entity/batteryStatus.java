package com.connected.car.vehicle.entity;

public enum batteryStatus {
    LOW, HIGH;
}
