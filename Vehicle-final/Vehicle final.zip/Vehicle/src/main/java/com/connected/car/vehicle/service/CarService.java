package com.connected.car.vehicle.service;

import java.util.List;

import com.connected.car.vehicle.dto.CarDto;

public interface CarService {

	CarDto createCar(CarDto carDto);
	CarDto getCarById(Integer userId);
	List<CarDto> getAllCars();
	CarDto updateCar(CarDto car, Integer carId);
	void deleteCar(Integer carId);

}
