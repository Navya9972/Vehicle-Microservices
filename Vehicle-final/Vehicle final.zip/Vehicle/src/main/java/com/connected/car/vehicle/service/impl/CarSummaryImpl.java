package com.connected.car.vehicle.service.impl;

import com.connected.car.vehicle.entity.Car;
import com.connected.car.vehicle.entity.CarSummary;
import com.connected.car.vehicle.entity.TripDetails;
import com.connected.car.vehicle.repository.CarRepository;
import com.connected.car.vehicle.repository.CarSummaryRepository;
import com.connected.car.vehicle.repository.TripDetailsRepository;
import com.connected.car.vehicle.service.CarSummaryService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;

@Service
public class CarSummaryImpl implements CarSummaryService {


    @Autowired
    private CarSummaryRepository carSummaryRepository;

    @Autowired
    private TripDetailsRepository tripDetailsRepository;

    @Autowired
    private CarRepository carRepository;

    public double calculateMileage(long carId, long tripDetailsId)
    {
        double totalDistance=carSummaryRepository.findTotalDistanceByTripDetailsId(tripDetailsId);
        double fuelConsumed=carSummaryRepository.findFuelConsumptionByTripDetailsId(tripDetailsId);

        double mileage= totalDistance/fuelConsumed;
        CarSummary carSummary=carSummaryRepository.findCarSummaryByTripDetailsId(tripDetailsId);
        carSummary.setMileage(mileage);
        carSummaryRepository.save(carSummary);


        return mileage;
    }


    public List<TripDetails> listOfTripForCarId(long carId) {
        List<TripDetails> tripDetails=tripDetailsRepository.findAllTripDetailsByCarId(carId);
        System.out.println(tripDetails);


        return tripDetails;

    }

    public double calculateFuelConsumption(long carId, long tripDetailsId) {
        double initialFuelReading = tripDetailsRepository.findInitialFuelReadingByTripDetailsId(tripDetailsId);
        double currentFuelReading = tripDetailsRepository.findCurrentFuelReadingByTripDetailsId(tripDetailsId);
        double FuelConsumption = initialFuelReading - currentFuelReading;
        CarSummary carSummary=carSummaryRepository.findCarSummaryByTripDetailsId(tripDetailsId);
        carSummary.setFuelConsumption(FuelConsumption);
        carSummaryRepository.save(carSummary);
        return FuelConsumption;


    }


    public double calculatePresentAvgMileage(long carId,List<Long> tripDetailsIdList) {

        double sumMileage=0;
        double avgMileage=0;
        for(int i=0;i<tripDetailsIdList.size();i++) {
            CarSummary carSummary=carSummaryRepository.findCarSummaryByTripDetailsId(tripDetailsIdList.get(i));
            System.out.println(carSummary);
            if (carSummary != null && carSummary.getMileage() != 0 && !Double.isNaN(carSummary.getMileage()))
            sumMileage =(sumMileage+carSummary.getMileage());
        }
        System.out.println(sumMileage);

        avgMileage= sumMileage/tripDetailsIdList.size();
        Car car=carRepository.findByCarId(carId);
        car.setOverallAvgMileage(avgMileage);
        carRepository.save(car);
        for(int i=0;i<tripDetailsIdList.size();i++) {
            CarSummary carSummary = carSummaryRepository.findCarSummaryByTripDetailsId(tripDetailsIdList.get(i));
            carSummary.setOverallAvgMileage(avgMileage);
            carSummaryRepository.save(carSummary);
        }
        return avgMileage;

    }

    @Override
    public double calculateTotalDistance(long carId, long tripDetailsId) {
        double odometerStartReading = tripDetailsRepository.findOdometerStartReadingByTripDetailsId(tripDetailsId);
        double odometerEndReading= tripDetailsRepository.findOdometerEndReadingByTripDetailsId(tripDetailsId);
        double totalDistance = odometerEndReading - odometerStartReading;
        CarSummary carSummary=carSummaryRepository.findCarSummaryByTripDetailsId(tripDetailsId);
        carSummary.setTotalDistance(totalDistance);
        carSummaryRepository.save(carSummary);
        return totalDistance;

    }



    @Override
    public double calculateDuration(long carId, long tripDetailsId) {
        double travelStartTime = tripDetailsRepository.findTravelStartTimeByTripDetailsId(tripDetailsId);
        double travelEndTime = tripDetailsRepository.findTravelEndTimeByTripDetailsId(tripDetailsId);
        // Convert double values to LocalDateTime
        LocalDateTime startTime = Instant.ofEpochMilli((long) travelStartTime).atZone(ZoneId.systemDefault()).toLocalDateTime();
        LocalDateTime endTime = Instant.ofEpochMilli((long) travelEndTime).atZone(ZoneId.systemDefault()).toLocalDateTime();
        long durationInMinutes = Duration.between(startTime, endTime).toMinutes();
        CarSummary carSummary = carSummaryRepository.findCarSummaryByTripDetailsId(tripDetailsId);
        carSummary.setDuration(Duration.ofDays(800));
        carSummaryRepository.save(carSummary);
        return durationInMinutes;
    }

    public void getCarSummary(long carId,long tripDetailsId) {
        calculateMileage(carId,tripDetailsId);
       // calculateDuration(carId,tripDetailsId);
        calculateFuelConsumption(carId,tripDetailsId);
        calculateTotalDistance(carId,tripDetailsId);
        List<TripDetails> tripDetailsList=listOfTripForCarId(carId);
        List<Long> listofTripIdforCarid=new ArrayList<>();
        for (int i=0;i<listofTripIdforCarid.size();i++)
        {
            listofTripIdforCarid.add(tripDetailsList.get(i).getTripDetailsId());
        }
        //calculatePresentAvgMileage(carId,listofTripIdforCarid);



    }
}
