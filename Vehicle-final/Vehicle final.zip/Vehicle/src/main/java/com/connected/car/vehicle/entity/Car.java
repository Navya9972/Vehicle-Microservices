package com.connected.car.vehicle.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Table;
import jakarta.persistence.Id;

@Entity
@Table(name="car")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class Car {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int carId;
	private String model;
	private String description;
	private String registrationNumber;
	private String manufacturer;
	private String manufactureYear;
	private double overallAvgMileage;
	
}
