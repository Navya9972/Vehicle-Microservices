package com.connected.car.vehicle.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.connected.car.vehicle.dto.CarDto;
import com.connected.car.vehicle.service.CarService;

@RestController
@RequestMapping("/v1/api/vehicles")
public class CarController {

	@Autowired
	private CarService carService;
	
	@PostMapping("/create")
	public ResponseEntity<CarDto> createCar(@RequestBody CarDto carDto){
		CarDto createCarDto=carService.createCar(carDto);
		return new ResponseEntity<>(createCarDto, HttpStatus.CREATED);
	}
	
	@GetMapping("/getCar/{carId}")
	public ResponseEntity<CarDto> getCar(@PathVariable("carId") Integer carId){
		return ResponseEntity.ok(carService.getCarById(carId));
	}
	
	@GetMapping("/getAllCars")
	public ResponseEntity<List<CarDto>> getAllCars(){
		return ResponseEntity.ok(carService.getAllCars());
	}
	
	@PutMapping("/update/{carId}")
	public ResponseEntity<CarDto> updateCar(@RequestBody CarDto carDto, @PathVariable("carId") Integer carId){
		CarDto updatedCar=carService.updateCar(carDto, carId);
		return new ResponseEntity<>(updatedCar, HttpStatus.OK);
	}
	
	@DeleteMapping("/delete/{carId}")
	public String deleteCar(@PathVariable("carId")Integer carId){
		carService.deleteCar(carId);
		return "Car Deleted successfully!";
	}
	
}
